#!/usr/bin/env python3
# -*- coding: utf-8 -*-


global titles
titles = None


class Title:
    def __init__(self):
        self.key = None
        self.id = None

    def setId(self, id):
        self.id = id.upper()


global nsuIdMap
nsuIdMap = {}

global regionTitles
regionTitles = {}


def data(region=None, language=None):
    global regionTitles
    global titles

    if region:
        if region not in regionTitles:
            regionTitles[region] = {}

        if language not in regionTitles[region]:
            regionTitles[region][language] = {}

        return regionTitles[region][language]

    if titles is None:
        titles = {}
    return titles


def items(region=None, language=None):
    if region:
        return regionTitles[region][language].items()

    return data().items()


def get(key, region=None, language=None):
    key = key.upper()

    if key not in data(region, language):
        t = Title()
        t.setId(key)
        data(region, language)[key] = t
    return data(region, language)[key]


def contains(key, region=None):
    return key in data(region)


def erase(id):
    id = id.upper()
    del data()[id]


def set(key, value):
    data()[key] = value


def keys(region=None, language=None):
    if region:
        return regionTitles[region][language].keys()

    return titles.keys() if titles is not None else {}
